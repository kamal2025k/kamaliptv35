const manifest = [
  "https://warez.la/player_api.php?username=336813&password=458453",
  "https://starplustv.site/player_api.php?username=69754974281040&password=247129511903",
  "http://138.255.102.3:25461/player_api.php?username=FOXSPORTS1HDsd&password=RRZKamZw9a",
  "http://7go.xyz:8080/player_api.php?username=15junior&password=as1266375",
  "http://6oclock.xyz/player_api.php?username=oVTsSvYjZu&password=cAXDNm9LY9",
  "https://mainsrv.contentgftp.xyz/player_api.php?username=Geraldo&password=12345678",
  "http://iptv.nextnet.krd:25461/get.php?username=nextnet&password=3738",
];

console.log(manifest);
